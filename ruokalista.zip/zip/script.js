var ruoka1,ruoka2,ruoka3,ruoka4,ruoka5,ruoka6;
  var ruoka = [];
var index;



var rmaanantai, rtiistai, rkeskiviikko, rtorstai, rperjantai =[];
function sleep(milliseconds)
{
  var start = new Date().getTime();
  for (var i = 0; i < 1e7; i++) {
    if ((new Date().getTime() - start) > milliseconds){
      break;
    }
  };
}//sleep end



var luuppaaja = function(ruokalista_array,weekday) {
  var index = "";
  var days = ['Sunday','Maanantai','Tiistai','Keskiviikko','Torstai','Perjantai','Saturday'];
 Date.prototype.getDayName = function() {
        return days[ this.getDay() ];
    };
  var now = new Date();
 dayname = now.getDayName();
 

  if (weekday=="Maanantai"){
    $("#maanantainruokalista").html(weekday + '<br>');
    if (dayname===weekday)
    {     
          $("#thisday").html(weekday + '<br>');

    }
      for (index = 0; index < ruokalista_array.length; ++index) {
    if (dayname===weekday)
    {     
          $("#thisday").html($("#thisday").html() + ruokalista_array[index] + '<br />');

    }
    $("#maanantainruokalista").html($("#maanantainruokalista").html() + ruokalista_array[index] + '<br />');
    
}
}
if (weekday=="Tiistai"){
    $("#tiistainruokalista").html(weekday + '<br>');
    if (dayname===weekday)
    {     
          $("#thisday").html(weekday + '<br>');

    }
      for (index = 0; index < ruokalista_array.length; ++index) {
    if (dayname===weekday)
    {
          $("#thisday").html($("#thisday").html() + ruokalista_array[index] + '<br />');

    }
    $("#tiistainruokalista").html($("#tiistainruokalista").html() + ruokalista_array[index] + '<br />');
    
}
}
if (weekday=="Keskiviikko"){
    $("#keskiviikonruokalista").html(weekday + '<br>');
    if (dayname===weekday)
    {     
          $("#thisday").html(weekday + '<br>');

    }
      for (index = 0; index < ruokalista_array.length; ++index) {
    if (dayname===weekday)
    {
          $("#thisday").html($("#thisday").html() + ruokalista_array[index] + '<br />');

    }
    $("#keskiviikonruokalista").html($("#keskiviikonruokalista").html() + ruokalista_array[index] + '<br />');
    
}
}
if (weekday=="Torstai"){
    $("#torstainruokalista").html(weekday + '<br>');
    if (dayname===weekday)
    {     
          $("#thisday").html(weekday + '<br>');

    }
      for (index = 0; index < ruokalista_array.length; ++index) {
    if (dayname===weekday)
    {
          $("#thisday").html($("#thisday").html() + ruokalista_array[index] + '<br />');

    }
    $("#torstainruokalista").html($("#torstainruokalista").html() + ruokalista_array[index] + '<br />');
    
}
}
if (weekday=="Perjantai"){
    $("#perjantainruokalista").html(weekday + '<br>');
    if (dayname===weekday)
    {     
          $("#thisday").html(weekday + '<br>');

    }
      for (index = 0; index < ruokalista_array.length; ++index) {
    if (dayname===weekday)
    {
          $("#thisday").html($("#thisday").html() + ruokalista_array[index] + '<br />');

    }
        $("#perjantainruokalista").html($("#perjantainruokalista").html() + ruokalista_array[index] + '<br />');

    
}
}


};//luuppaaja end


var callback = function(ruoka,weekday) {
  if (weekday=="Maanantai"){
      rmaanantai = ruoka;
      luuppaaja(rmaanantai,weekday);
      
    }
    sleep(200);

    if (weekday=="Tiistai"){
      rtiistai = ruoka;
      luuppaaja(rtiistai,weekday);
sleep(200);
    }
    if (weekday=="Keskiviikko"){
      rkeskiviikko = ruoka;
      luuppaaja(rkeskiviikko,weekday);
    }
    sleep(200);
    if (weekday=="Torstai"){
      rtorstai = ruoka;
      luuppaaja(rtorstai,weekday);
      sleep(200);
    }if (weekday=="Perjantai"){
      rperjantai = ruoka;
      luuppaaja(rperjantai,weekday);
    }
};//callback end
var ajax = function(day,month,weekday)
{
$.get( "ajax.php?date=" + day + "&month=" + month, function( data ) {
  if (data.courses.length===6) {
  ruoka1 = data.courses[0].title_fi;
  ruoka2 = data.courses[1].title_fi;
  ruoka3 = data.courses[2].title_fi;
  ruoka4 = data.courses[3].title_fi;
  ruoka5 = data.courses[4].title_fi;
  ruoka6 = data.courses[5].title_fi;
  ruoka = [ruoka1,ruoka2,ruoka3,ruoka4,ruoka5,ruoka6];
  
callback(ruoka,weekday);

 
  }
  
  if (data.courses.length===5) {
  ruoka1 = data.courses[0].title_fi;
  ruoka2 = data.courses[1].title_fi;
  ruoka3 = data.courses[2].title_fi;
  ruoka4 = data.courses[3].title_fi;
  ruoka5 = data.courses[4].title_fi;
  ruoka = [ruoka1,ruoka2,ruoka3,ruoka4,ruoka5];
 

  callback(ruoka,weekday);
}
});
}; //ajax end
$(function() {
 var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
 Date.prototype.getDayName = function() {
        return days[ this.getDay() ];
    };

 var now = new Date();
 dayname = now.getDayName();
 day(dayname);
});//ready end
var day = function(day) {
  if (day==="Monday")
  {
var day = new Date(new Date().getTime() + 1 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();

ajax(d,m,'Maanantai');

sleep(200);

var day = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ajax(d,m,'Tiistai');

var day = new Date(new Date().getTime() + 48 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ajax(d,m,'Keskiviikko');

var day = new Date(new Date().getTime() + 72 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ajax(d,m,'Torstai');

var day = new Date(new Date().getTime() + 96 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ajax(d,m,'Perjantai');
  }
  if (day==="Tuesday")
  {
   var day = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();

ajax(d,m,'Maanantai');

sleep(200);

var day = new Date(new Date().getTime() - 1 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ajax(d,m,'Tiistai');

var day = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ajax(d,m,'Keskiviikko');

var day = new Date(new Date().getTime() + 48 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ajax(d,m,'Torstai');

var day = new Date(new Date().getTime() + 72 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ajax(d,m,'Perjantai'); 
  }
  if (day==="Wednesday")
  {
    var day = new Date(new Date().getTime() - 48 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();

ajax(d,m,'Maanantai');

sleep(200);

var day = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ajax(d,m,'Tiistai');

var day = new Date(new Date().getTime() + 1 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ajax(d,m,'Keskiviikko');

var day = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ajax(d,m,'Torstai');

var day = new Date(new Date().getTime() + 48 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ajax(d,m,'Perjantai');
  }
  if (day==="Thursday")
  {
   var day = new Date(new Date().getTime() - 72 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();

ajax(d,m,'Maanantai');

sleep(200);

var day = new Date(new Date().getTime() - 48 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ajax(d,m,'Tiistai');

var day = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ajax(d,m,'Keskiviikko');

var day = new Date(new Date().getTime() +1 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ajax(d,m,'Torstai');

var day = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ajax(d,m,'Perjantai'); 
  }
  if (day==="Friday")
  {
    var day = new Date(new Date().getTime() - 96 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();

ajax(d,m,'Maanantai');

sleep(200);

var day = new Date(new Date().getTime() - 72 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ajax(d,m,'Tiistai');

var day = new Date(new Date().getTime() - 48 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ajax(d,m,'Keskiviikko');

var day = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ajax(d,m,'Torstai');

var day = new Date(new Date().getTime() + 1 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ajax(d,m,'Perjantai');
  }

};//day end

/*
  function sleep(milliseconds) {
  var start = new Date().getTime();
  for (var i = 0; i < 1e7; i++) {
    if ((new Date().getTime() - start) > milliseconds){
      break;
    }
  }
}
var luuppaaja = function(ruokalista_array,weekday){
  var index = "";
  if (weekday=="Maanantai"){
    $("#maanantainruokalista").html($("p").html() + weekday + '<br>');
      for (index = 0; index < ruokalista_array.length; ++index) {
    console.log(ruokalista_array[index]);
    $("#maanantainruokalista").html($("#maanantainruokalista").html() + ruokalista_array[index] + '<br />');
    
}
if (weekday=="Tiistai"){
    $("#tiistainruokalista").html($("p").html() + weekday + '<br>');
      for (index = 0; index < ruokalista_array.length; ++index) {
    console.log(ruokalista_array[index]);
    $("#tiistainruokalista").html($("#tiistainruokalista").html() + ruokalista_array[index] + '<br />');
    
}
      
    }
  $("p").html($("p").html() + weekday + '<br>');
  
  for (index = 0; index < ruokalista_array.length; ++index) {
    console.log(ruokalista_array[index]);
    $("p").html($("p").html() + ruokalista_array[index] + '<br />');
    
}
}
var rmaanantai, rtiistai, rkeskiviikko, rtorstai, rperjantai =[];

 var callback = function(ruoka,weekday) {
    if (weekday=="Maanantai"){
      rmaanantai = ruoka;
      luuppaaja(rmaanantai,weekday);
      
    }
    sleep(200);

    if (weekday=="Tiistai"){
      rtiistai = ruoka;
      luuppaaja(rtiistai,weekday);
sleep(200);
    }
    if (weekday=="Keskiviikko"){
      rkeskiviikko = ruoka;
      luuppaaja(rkeskiviikko,weekday);
    }
    sleep(200);
    if (weekday=="Torstai"){
      rtorstai = ruoka;
      luuppaaja(rtorstai,weekday);
      sleep(200);
    }if (weekday=="Perjantai"){
      rperjantai = ruoka;
      luuppaaja(rperjantai,weekday);
    }

 };



  function  ajax(date,month,weekday) {
    $.get( "ajax.php?date=" + date + "&month=" + month, function( data ) {
    
  
  if (data.courses.length===6) {
  ruoka1 = data.courses[0].title_fi;
  ruoka2 = data.courses[1].title_fi;
  ruoka3 = data.courses[2].title_fi;
  ruoka4 = data.courses[3].title_fi;
  ruoka5 = data.courses[4].title_fi;
  ruoka6 = data.courses[5].title_fi;
  ruoka = [ruoka1,ruoka2,ruoka3,ruoka4,ruoka5,ruoka6];
  
callback(ruoka,weekday);

 
  }
  
  if (data.courses.length===5) {
  ruoka1 = data.courses[0].title_fi;
  ruoka2 = data.courses[1].title_fi;
  ruoka3 = data.courses[2].title_fi;
  ruoka4 = data.courses[3].title_fi;
  ruoka5 = data.courses[4].title_fi;
  ruoka = [ruoka1,ruoka2,ruoka3,ruoka4,ruoka5];
 

  callback(ruoka,weekday);
  }
  
  
 

});
  }
  $(function() {
 $friday =  Date.today().is().friday();
 $monday =  Date.today().is().monday();
 $tuesday = Date.today().is().tuesday();
 $wednesday = Date.today().is().wednesday();
 $thursday = Date.today().is().thursday();
 daynumber($friday);
});

  function daynumber (day) {
    
    if($friday)
    {
      var day = new Date(new Date().getTime() - 96 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();

ruoka[0] = ajax(d,m,'Maanantai');

sleep(200);

var day = new Date(new Date().getTime() - 72 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ruoka[1] =ajax(d,m,'Tiistai');

var day = new Date(new Date().getTime() - 48 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ruoka[2] =ajax(d,m,'Keskiviikko');

var day = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ruoka[3] =ajax(d,m,'Torstai');

var day = new Date(new Date().getTime() + 1 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ruoka[4] =ajax(d,m,'Perjantai');
    }
    if ($monday!="")
  {
    var day = new Date(new Date().getTime() + 1 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();

ruoka[0] = ajax(d,m,'Maanantai');

sleep(200);

var day = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ruoka[1] =ajax(d,m,'Tiistai');
sleep(200);
var day = new Date(new Date().getTime() + 48 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ruoka[2] =ajax(d,m,'Keskiviikko');
sleep(200);
var day = new Date(new Date().getTime() + 72 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ruoka[3] =ajax(d,m,'Torstai');
sleep(200);
var day = new Date(new Date().getTime() + 96 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ruoka[4] =ajax(d,m,'Perjantai');

}
if ($tuesday!="")
  {
    var day = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();

ruoka[0] = ajax(d,m,'Maanantai');

sleep(200);

var day = new Date(new Date().getTime() + 1 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ruoka[1] =ajax(d,m,'Tiistai');
sleep(200);
var day = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ruoka[2] =ajax(d,m,'Keskiviikko');
sleep(200);
var day = new Date(new Date().getTime() + 48 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ruoka[3] =ajax(d,m,'Torstai');
sleep(200);
var day = new Date(new Date().getTime() + 72 * 60 * 60 * 1000);
var d = day.getDate();
var m = day.getMonth() + 1;
var y = day.getFullYear();
ruoka[4] = ajax(d,m,'Perjantai');

}
  }

*/

